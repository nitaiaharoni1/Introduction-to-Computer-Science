
/*

Assignment number   :   3.3

File Name           :   Eval 

Name                :   Nitai Aharoni

Student ID          :   203626742

Email               :   Nitai.Aharoni@post.idc.ac.il

*/

public class Eval {
	public static void main(String[] args) {
		Parser.init(args[0]);
		int total = Parser.nextInt();
		while (Parser.hasMoreChars()) {
			char Op1 = Parser.nextChar();
			int Num1 = Parser.nextInt();
				if (Op1 == '+') {
					total = total + Num1;
				} else if (Op1 == '-') {
					total = total - Num1;
				}
			}
		System.out.println(args[0] + " = " + total);
		}
	}
