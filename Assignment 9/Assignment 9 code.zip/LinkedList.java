package mms;
/**
 * Represents a list of Nodes. The list has a "first" pointer, which points to the first node in the list,
 * a "last" pointer, which points to the last node in the list, and a size, which is the number of nodes in the list.  
 */
public class LinkedList {

    // Three package-private fields come here.
	
	/**
	 * Constructs a new doubly-connected linked list.
	 */ 
	public LinkedList () {
	}
	
	/**
	 * Gets the node located at the given index in this list. 
	 * 
	 * @param index
	 *        the index of the node to retrieve, between 0 and size
	 * @throws IllegalArgumentException
	 *         if index is negative or greater than the list's size
	 * @return the node at the given index
	 */		
	public Node getNode(int index) {
        return null; // Replace with your code.
	}
	
	/**
	 * Creates a new Node object that points to the given memory block, and inserts the
	 * node to this list immediately prior to the given index (position in this list).
	 * <p>
	 * If the given index is 0, the new node becomes the first node in this list.
	 * <p>
	 * If the given index equals the size of this list, the new node becomes the last 
	 * node in this list.
	 * 
	 * @param block
	 *        the memory block to be inserted into the list
	 * @param index
	 *        the index before which the memory block should be inserted
	 * @throws IllegalArgumentException
	 *         if index is negative or greater than the list's size
	 */
	public void add(int index, MemoryBlock block) {
	}

	/**
	 * Creates a new node with a reference to the given memory block, and appends it to the end of this list
	 * (the node will become the list's last node).
	 * 
	 * @param block
	 *        the given memory block
	 */
	public void addLast(MemoryBlock block) {
	}
	
	/**
	 * Appends a node with the given block to the end of this list
	 * (the given block will become the list's last block).
	 * <b>This method is not an official part of the API and serves only testing purposes.</b>
	 * 
	 * @param block
	 *        the given memory block
	 */
	public void addLastTest(MemoryBlock block) {
	}

	/**
	 * Creates a new node with a reference to the given memory block, and inserts it at the beginning of this list
	 * (the node will become the list's first node).
	 * 
	 * @param block
	 *        the given memory block
	 */
	public void addFirst(MemoryBlock block) {
	}

	/**
	 * Gets the memory block located at the given index in this list.
	 * 
	 * @param index
	 *        the index of the retrieved memory block
	 * @return the memory block at the given index
	 * @throws IllegalArgumentException
	 *         if index is negative or greater than or equal to size
	 */
	public MemoryBlock getBlock(int index) {
		return null; // Replace with your code.
	}	

	/**
	 * Gets the index of the node pointing to the given memory block.
	 * 
	 * @param block
	 *        the given memory block
	 * @return the index of the block, or -1 if the block is not in this list
	 */
	public int indexOf(MemoryBlock block) {
		return 0; // Replace with your code.
	}

	/**
	 * Removes the given node from this list.	
	 * 
	 * @param node
	 *        the node that will be removed from this list
	 */
	public void remove(Node node) {
	}

	/**
	 * Removes from this list the node which is located at the given index.
	 * 
	 * @param index the location of the node that has to be removed.
	 * @throws IllegalArgumentException
	 *         if index is negative or greater than or equal to size
	 */
	public void remove(int index) {
	}

	/**
	 * Removes from this list the node pointing to the given memory block.
	 * 
	 * @param block the memory block that should be removed from the list
	 * @throws IllegalArgumentException
	 *         if the given memory block is not in this list
	 */
	public void remove(MemoryBlock block) {
	}	

	/**
	 * Returns an iterator over this list, starting with the first element.
	 */
	public ListIterator iterator(){
		return null; // Replace with your code.
	}
	
	/**
	 * A textual representation of this list, useful for debugging.
	 */
	public String toString() {
		return ""; // Replace with your code.
	}
}