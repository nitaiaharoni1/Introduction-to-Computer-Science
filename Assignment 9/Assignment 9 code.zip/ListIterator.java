package mms;
/*
 * Represents an iterator of a linked list.
 */
public class ListIterator {

    // current position in the list (cursor)
    public Node current;

    /** Constructs a list iterator,
     *  starting at the given node */
    public ListIterator(Node node) {
        current = node;
    }

    /** Checks if this iterator has more
     *  nodes to process */
    public boolean hasNext() {
        return true; // Replace with your code.
    }

    /** Returns the current element in the list
     * and advances the cursor */
    public MemoryBlock next() {
        return null; // Replace with your code.
    }
}