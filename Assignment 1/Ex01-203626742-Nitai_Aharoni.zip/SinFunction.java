/*

Assignment number   :   1.2

File Name           :   SinFunction

Name                :   Nitai Aharoni

Student ID          :   203626742

Email               :   Nitai.Aharoni@post.idc.ac.il

*/

public class SinFunction {
	public static void main(String[] args) {
		double pi = Math.PI / 4;
		System.out.println("sin(0)      = " + Math.sin(pi * 0));
		System.out.println("sin(1/4 PI) = " + Math.sin(pi * 1));
		System.out.println("sin(1/2 PI) = " + Math.sin(pi * 2));
		System.out.println("sin(3/4 PI) = " + Math.sin(pi * 3));
		System.out.println("sin(PI)     = " + Math.sin(pi * 4));
		System.out.println("sin(5/4 PI) = " + Math.sin(pi * 5));
		System.out.println("sin(3/2 PI) = " + Math.sin(pi * 6));
		System.out.println("sin(7/4 PI) = " + Math.sin(pi * 7));
		System.out.println("sin(2 PI)   = " + Math.sin(pi * 8));
	}
}
